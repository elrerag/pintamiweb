package cl.lherrera.main;

import java.util.List;

import cl.lherrera.daos.CursoDao;
import cl.lherrera.daos.FormaDePagoDao;
import cl.lherrera.entidades.CursoDTO;
import cl.lherrera.entidades.FormaDePagoDTO;
import cl.lherrera.entidades.InscripcionDTO;
import cl.lherrera.facades.Facade;
import cl.lherrera.daos.InscripcionDAO;

public class Principal {
	public static void main(String[] args) {
		probarFacade();
		System.out.println("tareas finalizadas");
		
	}
	
	public static void probarFacade() {
		Facade facade = new Facade();
		
		List <CursoDTO> listaDeCursos = facade.obtenerCursos();
		listaDeCursos.forEach(curso -> System.out.println(curso.getDescripcion()));
	}
	
	public static void probarInsertarInscripción() {
		InscripcionDAO inscripcionDao = new InscripcionDAO();
		InscripcionDTO dto = new InscripcionDTO();
		dto.setNombre("Hugo");
		dto.setCelular("554556398");
		dto.setIdCurso(1);
		dto.setIdFormaDePago(1);
		
		int resultado = inscripcionDao.insertarInscripcion(dto);
		System.out.println("acción terminada");
		System.out.println("resultado: " + resultado);
	}
	
	public static void probarFormaPago() {
		FormaDePagoDao formaPagoDao = new FormaDePagoDao();
		List <FormaDePagoDTO> listaDeFormaPago = formaPagoDao.obtieneFormasDePago();
		
		listaDeFormaPago.forEach(formaPago -> System.out.println(formaPago.getDescripcion()));
		System.out.println("Acción terminada");
	}

	public static void probarCursoDao() {
		CursoDao cursoDao = new CursoDao();
		List <CursoDTO> listaDeCursos = cursoDao.obtenerCursos();
		listaDeCursos.stream()
		.forEach(curso -> System.out.println(curso.getDescripcion()));
		
	}
}
