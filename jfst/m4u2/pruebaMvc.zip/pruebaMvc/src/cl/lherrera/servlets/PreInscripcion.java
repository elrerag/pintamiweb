package cl.lherrera.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.lherrera.entidades.CursoDTO;
import cl.lherrera.entidades.FormaDePagoDTO;
import cl.lherrera.facades.Facade;

@WebServlet("/preInscripcion")
public class PreInscripcion extends HttpServlet{

	private static final long serialVersionUID = -707784703567339582L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		
		Facade fachada = new Facade();
		List<CursoDTO> cursos = fachada.obtenerCursos();
		List<FormaDePagoDTO> formasDePago = fachada.obtenerFormasDePago();

		req.setAttribute("cursos", cursos);
		req.setAttribute("formasDePago", formasDePago);
		
		try {
			req.getRequestDispatcher("inscripcion.jsp").forward(req, resp);
		  }
		  catch (ServletException | IOException e) {
			  e.printStackTrace();
		  }
	
	}

}
