package cl.lherrera.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.lherrera.entidades.InscripcionDTO;
import cl.lherrera.facades.Facade;

@WebServlet("/postInscripcion")
public class PosInscripcion extends HttpServlet{

	private static final long serialVersionUID = -2533943119391365490L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		// inicializar facade
		Facade facade = new Facade();
		// obtener los valores del formulario
		String nombre = req.getParameter("nombre");
		String celular = req.getParameter("celular");
		int idCurso = Integer.parseInt(req.getParameter("idCurso"));
		int idFormaDePago = Integer.parseInt(req.getParameter("idFormaDePago"));
		// llenado del DTO
		InscripcionDTO inscripcionDto = new InscripcionDTO();
		inscripcionDto.setNombre(nombre);
		inscripcionDto.setCelular(celular);
		inscripcionDto.setIdCurso(idCurso);
		inscripcionDto.setIdFormaDePago(idFormaDePago);
		
		// id insertado
		int idInsc = facade.registrarInscripcion(inscripcionDto);
		
		// agregamos el id de la respuesta al request.
		req.setAttribute("idInsc", idInsc);
		
		// redireccionamos los objetos de comunicación cargados con datos, hacia otro servlet.
		try {
			req.getRequestDispatcher("/preConfirmacion").forward(req, resp);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}

	}
	
	

}
