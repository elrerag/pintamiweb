package cl.lherrera.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.driver.OracleDriver;

public class AccesoBaseDatos {
	
	private static final String DB_HOST = "jdbc:oracle:thin:@localhost:1521:XE";
	private static final String DB_USER_NAME = "mod4u2";
	private static final String DB_USER_PASS = "1234";
	
	// variable estática. Única instancia permitida.
	private static AccesoBaseDatos acceso;
	
	// variables de instancia
	private Connection conexion;
	
	// constructor privado para evitar instancias desde fuera.
	private AccesoBaseDatos() {}
	
	// única forma de obtener una instancia desde fuera.
	public static AccesoBaseDatos obtenerInstancia() {
		if(acceso == null) {
			acceso = new AccesoBaseDatos();
		}
		
		return acceso;
	}
	
	/**
	 * Obtiene una conexión a la base de datos. La cuál es única para la 
	 * instancia de la aplicación.
	 * @return
	 */
	public Connection obtenerConexion() {
		try {
			// registramos el driver: uso en lugar de Class.forname.
			DriverManager.registerDriver(new OracleDriver());
			conexion = DriverManager.getConnection(DB_HOST, DB_USER_NAME, DB_USER_PASS);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return conexion;
	}
}
