package cl.lherrera.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cl.lherrera.entidades.InscripcionDTO;
import cl.lherrera.utils.AccesoBaseDatos;

public class InscripcionDAO {
	// obtener la conexión.
	Connection conexion = (AccesoBaseDatos.obtenerInstancia()).obtenerConexion();
	
	public int insertarInscripcion(InscripcionDTO dto) {
		int max = getMaxId();
		
		String sqlTxt = "insert into mod4u2.inscripcion values(?, ?, ?, ?, ?)";
		
		try(
			// preparar consulta
			PreparedStatement ps = conexion.prepareStatement(sqlTxt);
		){
			ps.setInt(1, max);
			ps.setString(2, dto.getNombre());
			ps.setString(3, dto.getCelular());
			ps.setInt(4, dto.getIdCurso());
			ps.setInt(5, dto.getIdFormaDePago());

			if(ps.executeUpdate() != 1) {
				System.out.println("Error al insertar");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return max;
	}
	
	private int getMaxId() {
		int maxId = 0;
		String sqlTxt = "select max(id_inscripcion) + 1 maxId from mod4u2.inscripcion";

		try (
			// preparar consulta
			PreparedStatement ps = conexion.prepareStatement(sqlTxt);
			ResultSet filas = ps.executeQuery();
		) {
			if(filas.next())
				maxId = filas.getInt("maxId");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return maxId;
	}

}
