package cl.lherrera.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cl.lherrera.entidades.CursoDTO;
import cl.lherrera.utils.AccesoBaseDatos;

public class CursoDao {
	AccesoBaseDatos acceso = AccesoBaseDatos.obtenerInstancia();
	Connection conexion = acceso.obtenerConexion();

	public List<CursoDTO> obtenerCursos() {

		List<CursoDTO> listaDeCursos = new ArrayList<>();
		String sqlTxt = ("select id_curso, descripcion, precio from mod4u2.curso");
		
		try(
			PreparedStatement sentencia = conexion.prepareStatement(sqlTxt);
			ResultSet cursos = sentencia.executeQuery();
		){
			while (cursos.next()) {
				CursoDTO nuevoCurso = new CursoDTO();
				nuevoCurso.setIdCurso(cursos.getInt("id_curso"));
				nuevoCurso.setDescripcion(cursos.getString("descripcion"));
				nuevoCurso.setPrecio(cursos.getDouble("precio"));

				listaDeCursos.add(nuevoCurso);
			}

		} catch (SQLException e) {
			e.getStackTrace();
		}

		return listaDeCursos;

	}
}
