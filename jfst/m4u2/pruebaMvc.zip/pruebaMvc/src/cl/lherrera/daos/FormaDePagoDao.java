package cl.lherrera.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cl.lherrera.entidades.FormaDePagoDTO;
import cl.lherrera.utils.AccesoBaseDatos;

public class FormaDePagoDao {
	// obtener la conexión.
	Connection conexion = (AccesoBaseDatos.obtenerInstancia()).obtenerConexion();
	
	public List<FormaDePagoDTO> obtieneFormasDePago() {
		// lista para retornar
		List<FormaDePagoDTO> formasDePago = new ArrayList<>();

		// construir la consulta
		String sqlTxt = "select * from mod4u2.forma_pago"; 

		try(
			// preparar consulta
			PreparedStatement ps = conexion.prepareStatement(sqlTxt);
			ResultSet formasDePagoSets = ps.executeQuery();
		){
			while(formasDePagoSets.next()) {
				FormaDePagoDTO formaPago = new FormaDePagoDTO();
				formaPago.setIdFormaDePago(formasDePagoSets.getInt("id_forma_pago"));
				formaPago.setDescripcion(formasDePagoSets.getString("descripcion"));
				formaPago.setRecargo(formasDePagoSets.getDouble("recarga"));
				
				formasDePago.add(formaPago);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return formasDePago;
	}

}
