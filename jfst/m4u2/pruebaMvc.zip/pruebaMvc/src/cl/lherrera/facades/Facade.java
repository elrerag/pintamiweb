package cl.lherrera.facades;

import java.util.List;

import cl.lherrera.daos.CursoDao;
import cl.lherrera.daos.FormaDePagoDao;
import cl.lherrera.daos.InscripcionDAO;
import cl.lherrera.entidades.CursoDTO;
import cl.lherrera.entidades.FormaDePagoDTO;
import cl.lherrera.entidades.InscripcionDTO;

public class Facade {
	
	public int registrarInscripcion(InscripcionDTO dto) {
		InscripcionDAO dao = new InscripcionDAO();
		return dao.insertarInscripcion(dto);
	}

	public List<CursoDTO> obtenerCursos(){
		CursoDao dao = new CursoDao();
		return dao.obtenerCursos();
	}
	
	public List<FormaDePagoDTO> obtenerFormasDePago(){
		FormaDePagoDao dao = new FormaDePagoDao();
		return dao.obtieneFormasDePago();
	}

}
